package com.example.siste.sistema_prom;

public class Productos {
    public String imgen;
    public String titulo, precio;
    public  int id;
}
