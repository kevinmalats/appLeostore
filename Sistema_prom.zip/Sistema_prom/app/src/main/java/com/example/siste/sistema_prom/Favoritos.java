package com.example.siste.sistema_prom;

public class Favoritos {
    int id, idProducto;
    String imagen, nombre, precio;
}
